library(testthat)
library(maidentools)

test_check("maidentools")

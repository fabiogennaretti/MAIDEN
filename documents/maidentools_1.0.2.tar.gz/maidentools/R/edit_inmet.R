#' Editor of inmet files
#'
#' \code{edit_inmet} Modifies the meteorology with 'Deltas' and 'Omegas'.
#'
#' @details Deltas change average and keep daily distribution. Omegas keep
#' average and change daily distribution.
#'
#' @param inmetfile string, address of the inmet file
#' @param D_T float, Delta for temperature, (additive)
#' @param D_P float, Delta for precipitation, (multiplicative)
#' @param O_T float, Omega for temperature, (multiplicative)
#' @param O_P float, Omega for precipitation, (additive)
#'
#' @return Returns a success message upon editing the values in inmetfile.
#'
#' @examples
#' \dontrun{
#' inmetfile="pathtofile/inmet.txt"
#' #Decrease temperature by 3C, multiply precipitation by 1.2
#' edit_inmet(inmetfile,D_T=-3,D_P=1.2)
#' }
#'
#' @importFrom stats lm
#' @importFrom utils read.table
#' @importFrom utils write.table
#' @export

edit_inmet <- function(inmetfile,D_T=0,D_P=1,O_T=1,O_P=0) {
  if(!file.exists(inmetfile))
    stop(paste("Unable to find",inmetfile))

  # Read the file
  header = readLines(inmetfile, n=1) # QPFFN-XXXX-XXXX-Obs-Adjusted-No-RIEN
  inmet = utils::read.table(inmetfile, skip=1, header=F, dec=".")
  if(dim(inmet)[2]==8) names(inmet)=c("year","day","Tmax","Tmin","prec","CO2atm","d13Catm","d18Op")
  if(dim(inmet)[2]==7) names(inmet)=c("year","day","Tmax","Tmin","prec","CO2atm","d13Catm")
  if(dim(inmet)[2]==6) names(inmet)=c("year","day","Tmax","Tmin","prec","CO2atm")
  if(dim(inmet)[2]==5) names(inmet)=c("year","day","Tmax","Tmin","prec")
  if(header=="year-day-tmax-tmin-rad-prec-rhavg-wind-CO2")
    names(inmet) = c("year","day","Tmax","Tmin","rad","prec","RHavg","wind","CO2atm")
  if(header=="year-day-tmax-tmin-prec-CO2")
    names(inmet) = c("year","day","Tmax","Tmin","prec","CO2atm")
  if(header=="year-day-tmax-tmin-prec-CO2-d18Op-d18Ov")
    names(inmet) = c("year","day","Tmax","Tmin","prec","CO2atm","d18Op","d18Ov")
  if(header=="year-day-tmax-tmin-prec-CO2-d13C")
    names(inmet) = c("year","day","Tmax","Tmin","prec","CO2atm","d13Catm")

  # Apply Deltas
  inmet$Tmax = inmet$Tmax + D_T
  inmet$Tmin = inmet$Tmin + D_T
  inmet$prec = inmet$prec * D_P

  # Apply Omegas
  d=1:365
  for (yr in unique(inmet$year)){
    id = which(inmet$year==yr)
    Tyear = (inmet$Tmax[id] + inmet$Tmin[id])/2
    Pyear = inmet$prec[id]

    # fit yearly temperature to sinusoidal
    reslm <- stats::lm(Tyear ~ (sin(2*pi/365*d)+cos(2*pi/365*d)))
    C_int = summary(reslm)$coefficients[1,1]
    C_sin = summary(reslm)$coefficients[2,1]
    C_cos = summary(reslm)$coefficients[3,1]
    phase = atan(C_cos/C_sin) # phase (of sin)
    amp = C_cos/sin(phase)
    #Tsin = C_int + amp * sin(2*pi/365*d+phase)
    Tsin = C_int + (C_sin*sin(2*pi/365*d) + C_cos*cos(2*pi/365*d))

    # Apply Omega for T
    Tvar = Tyear - Tsin # daily variations are kept constant
    Tsin = C_int + O_T*(C_sin*sin(2*pi/365*d) + C_cos*cos(2*pi/365*d))
    Tyear_new = Tsin + Tvar
    inmet$Tmax[id] = inmet$Tmax[id] + Tyear_new - Tyear
    inmet$Tmin[id] = inmet$Tmin[id] + Tyear_new - Tyear

    # Apply Omega for P
    Pyear_new = Pyear*(1-O_P*sin(2*pi*d/365+phase)) #redistribute P
    Pyear_new = Pyear_new*sum(Pyear)/sum(Pyear_new) #keep yearly Prec
    inmet$prec[id] = Pyear_new
  }

  # Write the modified file
  utils::write.table(header,inmetfile,row.names=FALSE,col.names=FALSE,quote=FALSE)
  utils::write.table(inmet,inmetfile ,sep="\t",row.names=FALSE,col.names=FALSE,append=TRUE)
  return(paste("Successfully edited",inmetfile))
}

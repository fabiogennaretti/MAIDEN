#' Output extractor of MAIDENiso simulations
#'
#' \code{output_maiden} Extracts the outputs of MAIDENiso simulations with their
#' time units in mdf2 or mdf3 format.
#'
#' @details It looks for a file called filename in simdir. It then reads
#' filename and extracts the field called varname along with the "year" and
#' "day" fields. These are put together in a mdf2 format (if "day" does not
#' exist) or mdf3 format (if "day" exists) which is needed to usage in other
#' functions.
#'
#' @param simdir string, address of simulation folder
#' @param filename string, name of output file
#' @param varname string, name of output variable
#'
#' @return Returns a dataframe with the time fields (year and/or day) and the
#' extracted variable.
#'
#' @note The returned dataframe is in mdf2 or mdf3 format, designed to be used
#' in other functions of the package.
#'
#' @examples
#' \dontrun{
#' GPPday=output_maiden(simdir, filename="outalloc_d", varname="Acanopy")
#' }
#'
#' @importFrom utils read.table
#' @export

output_maiden <- function(simdir,filename,varname) {
  if(typeof(simdir) != "character")
    stop("Variable <simdir> must be of type character")
  if(typeof(filename) != "character")
    stop("Variable <filename> must be of type character")
  if(typeof(varname) != "character")
    stop("Variable <varname> must be of type character")

  outfile = utils::read.table(paste(simdir,paste(filename,".txt",sep=""),sep="/"), header=TRUE, dec=".")
  if(! varname %in% colnames(outfile))
    stop(paste("No field '",varname,"' found in '",filename,"'\n",sep=''))
  outvar = outfile[[varname]]
  year = outfile[["year"]]
  if("day" %in% names(outfile) | "yday" %in% names(outfile)) {
    if("day" %in% names(outfile)){
      day = outfile[["day"]]
    } else {
      day = outfile[["yday"]]
    }
    output = data.frame(year,day,outvar)
    names(output) = c("year","day",varname)
    print(paste(dim(output)[1]," data points (days) retrieved for variable '",varname,"' in ",filename,sep=''))
  } else {
    output = data.frame(year,outvar)
    names(output) = c("year",varname)
    print(paste(dim(output)[1]," data points (years) retrieved for variable '",varname,"' in ",filename,sep=''))
  }

  return(output)
}

#' Upscaler of Tree Ring Indices
#'
#' \code{TRI_upscale} Upscales tree ring index (TRI) series with the help of a
#' gross primary product (GPP) series, to create a Stem Growth series (gC/m2/d).
#'
#' @details Upscales tree ring index series (TRI) to create a Stem Growth series.
#' It upscales to the mean and standard deviation of a gross primary product (GPP)
#' series, and takes 9  percent of that (based on Pappas et al. 2020).
#'
#' @param TRI data.frame(year,TRI), TRI series to upscale
#' @param GPP data.frame(year,GPP), GPP series to use as reference
#' @param option 1 to upscale the sd, 2 to keep the relative values
#' @param allocfrac percent of GPP allocated to stem growth
#'
#' @return Returns Stem Growth in mdf2 format.
#'
#' @references C. Pappas et al. "Aboveground tree growth is a minor and
#'  decoupled fraction of boreal forest carbon input". Agricultural and Forest
#'  Meteorology (2020): 108030.
#'
#' @note Input TRI and GPP must be in mdf2 format. The standard option for 9
#' percent allocated to stem growth was only calculated for Quebec.
#'
#' @examples
#' \dontrun{
#' TRI=read.table("TRI_LG2.txt",header=T) #observed TRI
#' GPPyear=output_maiden(simdir,"outalloc_y","GPP") #simulated yearly GPP
#' StemGrowth=TRI_upscale(TRI,GPPyear) #TRI upscaled to gC/m2/d
#' }
#'
#' @export

TRI_upscale <- function(TRI,GPP,option=1,allocfrac=0.09) {
  requireNamespace("stats")
  requireNamespace("utils")

  year=intersect(TRI$year,GPP$year) #common years between the two series

  id.GPP=which(GPP$year %in% year)
  GPP=GPP[id.GPP,]
  GPP_sp=melvinspline(GPP$GPP,ssy=(rep(10,length(GPP$GPP))))
  GPP_res=GPP$GPP-GPP_sp
  mean.GPP=mean(GPP_sp)
  sd.GPP=stats::sd(GPP_res)

  id.TRI=which(TRI$year %in% year)
  TRI_sp=melvinspline(TRI$TRI[id.TRI],ssy=(rep(10,length(TRI$TRI[id.TRI]))))
  TRI_res=TRI$TRI[id.TRI]-TRI_sp
  mean.TRI=mean(TRI_sp)
  sd.TRI=stats::sd(TRI_res)

  if(option==1){ #upscales the sd
    SG=data.frame(year=TRI$year,StemGrowth=allocfrac*(((TRI$TRI-mean.TRI)/sd.TRI) * sd.GPP + mean.GPP))
  } else if(option==2){ #keeps the relative differences in TRI
    SG=data.frame(year=TRI$year,StemGrowth=allocfrac*((TRI$TRI/mean.TRI) * mean.GPP))
  }
  return(SG)
}

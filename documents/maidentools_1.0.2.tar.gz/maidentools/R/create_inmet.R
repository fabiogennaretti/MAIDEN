#' Creator of inmet files
#'
#' \code{create_inmet} Creates a basic inmet file in the current directory.
#'
#' @details It creates an inmet file with arbitrary meteorology that can be used
#' right away (for testing purposes).
#'
#' @param site string, to name the inmet file
#' @param year_first integer, first year to create
#' @param year_last integer, last year to create
#' @param Tyear float, yearly average temperature (C)
#' @param Pyear float, yearly precipitation (cm)
#' @param random logical, whether to randomize temperature and precipitation
#'
#' @return Returns address of the created inmet file
#'
#' @note Standard values create a meteorology of yearly average temperature of
#' 5C and yearly precipitation of 100cm.
#'
#' @examples
#' \dontrun{
#' site="testsite"
#' create_inmet(site,1990,2000)
#' }
#'
#' @importFrom utils write.table
#' @importFrom stats rnorm
#' @export

create_inmet <- function(site,year_first,year_last,Tyear=5,Pyear=100,random=T) {
  years=year_first:year_last
  nyears=length(years)
  inmet=data.frame(year=rep(years,each=365),
                   day=rep(1:365,nyears),
                   Tmax=rep(NA,nyears*365),
                   Tmin=rep(NA,nyears*365),
                   prec=rep(NA,nyears*365))

  # Create Temperature and Precipitation
  Tamp = 10     #daily temperature amplitude
  Tvar = 20     #yearly temperature variability
  Tdelay = 225  #warmest day of the year
  Pvar = 0.25   #variability of daily precipitation to average
  Pdelay = 90   #wettest day of the year

  inmet$Tmax = rep( Tyear + Tamp/2 + Tvar*sin(2*pi*((1:365 + Tdelay)/365)), nyears)
  inmet$prec = rep( Pyear/365*(1-Pvar*sin(2*pi*(1:365 + Pdelay)/365)), nyears)

  if(random) {
    inmet$Tmax = inmet$Tmax + rnorm(nyears*365,mean=0,sd=Tvar/5)
    inmet$Tmin = inmet$Tmax - rnorm(nyears*365,mean=Tamp,sd=Tamp/10)
    inmet$prec = inmet$prec + rnorm(nyears*365,mean=0,sd=Pyear/365/5)
    inmet$prec[which(inmet$prec<0)] = 0
  } else {
    inmet$Tmin = inmet$Tmax - Tamp
  }

  # Add the extra fields
  header="year-day-tmax-tmin-prec-CO2"
  inmet$CO2=create_dailydata(year_first,year_last,data="CO2")$CO2

  # Write the new file
  inmetfile=paste("inmet_",site,".txt",sep="")
  utils::write.table(header,inmetfile,row.names=FALSE,col.names=FALSE,quote=FALSE)
  utils::write.table(inmet,inmetfile ,sep="\t",row.names=FALSE,col.names=FALSE,append=TRUE)
  print(paste("Successfully created",inmetfile))
  return(paste(getwd(),inmetfile,sep="/"))
}

#' Correlation (Pearson) for MAIDENiso
#'
#' \code{cor_maiden} Calculates the Pearson correlation or p-values between two
#' series in mdf2 or mdf3 format, using only their overlap in time.
#'
#' @details x and y must both have the same fields (year and day if 3
#' dimensions, year if 2 dimensions). x and y are not required to have the same
#' number of rows, neither perfectly overlapping time fields.
#'
#' @param x data frame in mdf2 (year,X) or mdf3 (year,day,X)
#' @param y data frame in mdf2 (year,X) or mdf3 (year,day,X)
#' @param p logical, if true give back the p value instead of the correlation
#'
#' @return Returns the Pearson correlation or p-value between the last column of
#' x and the last column of y.
#'
#' @note It only considers those rows whose time fields are present in both
#' data frames.
#'
#' @examples
#' \dontrun{
#' x=data.frame(year=1990:2010,X=runif(21,min=-1,max=1))
#' y=data.frame(year=1985:2000,X=runif(16,min=-1,max=1))
#' cor_maiden(x,y)
#' }
#'
#' @export

cor_maiden <- function(x,y,p=F){
  dims=c(dim(x)[2],dim(y)[2])
  if(length(unique(dims)) != 1)
    stop("Both dataframes must have the same number of columns")
  dims=unique(dims)
  if(dims < 2 | dims > 3)
    stop("Dataframes must have either 2 or 3 columns (1 or 2 for time, +1 for data)")
  if(dims==2 & names(x[1]) != "year")
    stop(paste("x[,1] (",names(x)[1],") should be named 'year'",sep=""))
  if(dims==2 & names(y[1]) != "year")
    stop(paste("y[,1] (",names(y)[1],") should be named 'year'",sep=""))
  if(dims==3 & (names(x)[1] != "year" | names(x)[2] != "day"))
    stop(paste("x[,1] (",names(x)[1],") should be named 'year', x[,2] (",names(x)[2],") should be named 'day'",sep=''))
  if(dims==3 & (names(y)[1] != "year" | names(y)[2] != "day"))
    stop(paste("y[,1] (",names(y)[1],") should be named 'year', y[,2] (",names(y)[2],") should be named 'day'",sep=''))

  MERGED=merge(x,y,by=names(x)[1:(dim(x)[2]-1)])
  id=which(is.na(MERGED[,(dims)]) | is.na(MERGED[,(dims+1)]))
  if(length(id)>0) {
    MERGED=MERGED[-id,]
    print(paste("warning:",length(id),"rows were supressed because of NA values"))
  }
  mycor=stats::cor.test(MERGED[,(dims)],MERGED[,(dims+1)])
  if(p)
    return(mycor$p.value)
  else
    return(mycor$estimate)
}

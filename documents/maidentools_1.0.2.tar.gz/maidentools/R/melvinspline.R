#' Melvin spline
#'
#' \code{melvinspline} Calculates melvin spline of a vector.
#'
#' @details x and ssy must have equal length.
#'
#' @param x vector, series to which we apply the spline
#' @param ssy vector, rep(y,length(x)), where y is the size of the window for
#' the spline
#'
#' @return Returns the spline of x.
#'
#' @author Fabio Gennaretti
#'
#' @examples
#' x=runif(10,min=-1,max=1)
#' ssy=rep(10,length(x))
#' plot(x,type='l')
#' lines(melvinspline(x,ssy),col=2)
#'
#' @export

melvinspline <- function(x, ssy) {
  n <- length(x)
  arg <- cos(2 * pi/ssy)
  p <- (2 * (arg - 1)^2)/(arg + 2)

  a1 <- a2 <- a3 <- a4 <- rep(0, n + 2)
  a1[2 + (3:(n - 2))] <- 1
  a2[2 + (2:(n - 2))] <- -4 + p[2:(n - 2)]
  a3[2 + (1:(n - 2))] <- 6 + p[1:(n - 2)] * 4
  a4[2 + (1:(n - 2))] <- (x[1:(n - 2)] + x[3:n] - 2 * x[2:(n - 1)])

  for (i in 3:n) {
    a1[i] <- a1[i] * a3[i - 2]
    a2[i] <- (a2[i] - a1[i] * a2[i - 1]) * a3[i - 1]
    a3[i] <- 1/sqrt(a3[i] - a1[i]^2 - a2[i]^2)
    a4[i] <- (a4[i] - a4[i - 2] * a1[i] - a4[i - 1] * a2[i]) * a3[i]
  }

  for (i in (2 + seq(n - 2, 1, -1))) {
    a4[i] <- (a4[i] - a4[i + 1] * a2[i + 1] - a4[i + 2] * a1[i + 2]) * a3[i]
  }
  #Build smooth curve
  rwp <- x - (a4[1:n] - 2 * a4[2:(n + 1)] + a4[3:(n + 2)])
  return(rwp)
}

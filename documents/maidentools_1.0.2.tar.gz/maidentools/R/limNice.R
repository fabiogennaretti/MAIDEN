#' Nice plot limits
#'
#' \code{limNice} Rounds raw plot limits to something nice.
#'
#' @param lim double vector (length 2), raw limits to make nice
#'
#' @return Returns a double vector of length 2, a nicer lim for plotting.
#'
#' @keywords internal

limNice <- function(lim) {
  if(!(length(lim)==0 | length(lim)==2))
    stop("lim must have length 2")
  Mymin=lim[1] ; Mymax=lim[2]
  if(Mymin>=Mymax)
    stop("lim[2] must be > lim[1]")

  #first correction: rounded range and center of distribution
  range=abs(roundUpNice(Mymax-Mymin))
  rounding=range/2
  center=rounding*round(0.5*(Mymin+Mymax)/rounding)
  lim=c(center-range/2,center+range/2)
  while(lim[1]>Mymin) lim[1]=lim[1]-rounding
  while(lim[2]<Mymax) lim[2]=lim[2]+rounding

  #second correction: make one limit 0 if appropriate
  if(abs(center)/range<5){
    if(Mymin>0) lim[1]=0
    if(Mymax<0) lim[2]=0
  }

  return(lim)
}

#' Round Up Nice
#'
#' \code{roundUpNice} Upgrade from round(), to round up to nice numbers.
#'
#' @param x numbers to round up
#' @param nice numbers considered as nice (without 0s after)
#'
#' @return Returns nicely rounded numbers.
#'
#' @keywords internal

roundUpNice <- function(x, nice=c(1,1.2,1.5,2,3,4,5,6,8,10)) {
  if(length(x) == 0) stop("'x' is empty")

  y = rep(NA,length(x))
  for (i in 1:length(x)){
    if(x[i]>0) {
      y[i] = 10^floor(log10(x[i])) * nice[[min(which(x[i] <= 10^floor(log10(x[i])) * nice))]]
    } else if(x[i]<0) {
      y[i] = - 10^floor(log10(-x[i])) * nice[[max(which(-x[i] >= 10^floor(log10(-x[i])) * nice))]]
    } else {
      y[i] = 0
    }
  }
  return(y)
}

#' Selector of years in inmet files
#'
#' \code{select_inmet} Selects a range of years from an inmet file.
#'
#' @details Reads the file, keeps the specified range from it, and writes it in
#' the destination file (by default, same as the original file).
#'
#' @param inmetfile string, address of the inmet file.
#' @param year_first integer, first year to select.
#' @param year_last integer, last year to select.
#' @param dest string, address of the destination (new inmet file).
#'
#' @return Returns a success message upon cropping inmetfile.
#'
#' @note It selects the overlap between year_first-year_last and those in the file.
#'
#' @examples
#' \dontrun{
#' select_inmet(inmetfile,1990,2000,dest="pathtonewfile/inmet2.txt")
#' }
#'
#' @importFrom utils read.table
#' @importFrom utils write.table
#' @export

select_inmet <- function(inmetfile,year_first,year_last,dest=c()) {
  if(!file.exists(inmetfile))
    stop(paste("Unable to find",inmetfile))
  if(length(dest)==0)
    dest=inmetfile
  if(file.exists(dest))
    warning(paste("destination file",dest,"already exists"))

  # Read the file
  header = readLines(inmetfile, n=1)
  inmet = utils::read.table(inmetfile, skip=1, header=F, dec=".")

  ori_years=unique(inmet[,1])
  oy1=min(ori_years)
  oy2=max(ori_years)
  if(year_last<oy1)
    stop(paste0("No overlap between selected (",year_first,"-",year_last,") and available (",oy1,"-",oy2,") ranges"))
  if(year_first<oy1)
    year_first=oy1
  if(year_last>oy2)
    year_last=oy2
  id=which(inmet[,1] %in% year_first:year_last)
  inmet=inmet[id,]

  # Write the modified file
  utils::write.table(header,dest,row.names=FALSE,col.names=FALSE,quote=FALSE)
  utils::write.table(inmet,dest ,sep="\t",row.names=FALSE,col.names=FALSE,append=TRUE)
  if(inmetfile==dest)
    return(paste0("Selected ",year_first,"-",year_last," from original range ",oy1,"-",oy2," in inmetfile"))
  else
    return(paste0("Selected ",year_first,"-",year_last," from original range ",oy1,"-",oy2," in inmetfile, written to ",dest))
}

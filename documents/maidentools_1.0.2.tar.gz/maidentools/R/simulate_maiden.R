#' Simulate MAIDENiso
#'
#' \code{simulate_maiden} Runs MAIDENiso, provided the necessary inputs and
#' executable.
#'
#' @details If no simulation folder or input files are provided, it will look
#' for them in the current folder. The executable must always be provided. The
#' address of the executable must be complete (no referenced to home folder).
#'
#' @param simdir folder where to run MAIDENiso
#' @param P dataframe, containing the values of parameters (and their names as
#' colnames) if you want to change them
#' @param inmetfile name of the inmet file to use
#' @param inparfile name of the inpar file to use
#' @param maidendir folder where to find the executable of MAIDENiso
#' @param stdout logical, print terminal outputs
#'
#' @return Returns 0 if execution was not interrupted.
#'
#' @note Always check the output files to see if everything runs smoothly.
#'
#' @examples
#' \dontrun{
#' simulate_maiden(maidendir=maidendir)
#' }
#'
#' @export

simulate_maiden <- function(simdir=getwd(),P=c(),inmetfile="inmet.txt",inparfile="inpar2.txt",maidendir,stdout=F){
  if(grepl("~",maidendir))
    stop(paste0("Please write the full address for maidendir: unacceptable character '~' in ",maidendir))
  if(!dir.exists(simdir)){
    dir.create(simdir,recursive=TRUE)
    print(paste("Created",simdir))
  }
  if(!file.exists(inmetfile))
    stop(paste("inmetfile",inmetfile,"not found"))
  if(!file.exists(inparfile))
    stop(paste("inparfile",inparfile,"not found"))

  invisible(file.copy(from=inmetfile, to=paste(simdir,"inmet.txt",sep="/"), overwrite=TRUE))
  invisible(file.copy(from=inparfile, to=paste(simdir,"inpar2.txt",sep="/"), overwrite=TRUE))
  if(length(P)>0) edit_inpar(paste(simdir,"inpar2.txt",sep="/"),rownames(P),P$P)
  currentdir=getwd()
  setwd(simdir)
  switch(Sys.info()[['sysname']],
         Windows= {executable=list.files(path=maidendir,pattern=".exe")},
         Darwin = {executable=list.files(path=maidendir,pattern=".out")}
         )
  if(length(executable)==0)
    stop("Executable not found")
  if(length(executable)>1)
    stop(paste("Too many executables found:",paste(executable,collapse=", ")))
  system2(paste(maidendir,executable,sep="/"), stdout=stdout)
  setwd(currentdir)
  return(0)
}

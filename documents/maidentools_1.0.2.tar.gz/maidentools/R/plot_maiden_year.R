#' Plot Maiden outputs within the year
#'
#' \code{plot_maiden_year} Plots data frames, from data in mdf3 format, using
#' only the 'day' field to plot the x axis between 1 and 365.
#'
#' @details Plots the list of mdf3 data frames specified in datalist, using the
#' field 'day' in the x axis between 1 and 365. Different years are plotted in
#' the same graphic, either as several lines or (if average=T) as average of the
#' years and a shade for dispersion. If export=T, it creates a .jpeg instead of
#' making a plot. If label=character(), no legend is made.
#'
#' @param datalist list(data.frame("year","day",variable)), list of data frames
#' @param label character vector, labels for each data frame
#' @param export logical, whether to export the figure instead of plotting
#' @param filename character, name of the exported jpeg
#' @param xlim double vector (length 2), limits of x axis
#' @param ylim double vector (length 2), limits of y axis
#' @param ylab character, label of y axis
#' @param col integer array, line color
#' @param lty integer array, line type
#' @param average logical, whether to average the data from each day
#' @param shade logical(F) or character, option for shade ('sd' or 'error')
#'
#' @return No return value.
#'
#' @note The plotted data frames are designed in format mdf3.
#'
#' @examples
#' \dontrun{
#' plot_maiden_year(list(GPPday),label="Daily simulated GPP",export=TRUE)
#' }
#'
#' @importFrom graphics par
#' @importFrom graphics plot
#' @importFrom graphics axis
#' @importFrom graphics lines
#' @importFrom graphics polygon
#' @importFrom graphics legend
#' @importFrom grDevices jpeg
#' @importFrom grDevices col2rgb
#' @importFrom grDevices rgb
#' @importFrom grDevices dev.off
#' @importFrom stats aggregate
#' @importFrom stats sd
#' @importFrom stats quantile
#' @export

plot_maiden_year <- function(datalist,label=character(),export=F,filename=character(),
                             xlim=double(),ylim=double(),ylab=character(),
                             col=c(),lty=c(),average=F,shade=F) {
  if(! typeof(export)=="logical")
    stop("variable 'export' must be logical")
  simulations=length(datalist)
  labels=length(label)
  if(labels>0 & simulations != labels)
    stop(paste("Number of objects in datalist (",simulations,") and labels (",labels,") must be equal",sep=""))
  dims=rep(NA,simulations)
  for(i in 1:simulations) dims[i]=dim(datalist[[1]])[2]
  if(length(unique(dims)) != 1)
    stop("All dataframes in datalist must have the same number of columns")
  dims=unique(dims)
  for(i in 1:simulations) if(dims==2 & names(datalist[[i]])[1] != "day")
    stop(paste("datalist[[",i,"]][,1] should be named 'day'",sep=""))
  for(i in 1:simulations) if(dims==3 & (names(datalist[[i]])[2] != "day" | names(datalist[[i]])[1] != "year"))
    stop(paste("datalist[[",i,"]][,1] should be named 'year', datalist[[",i,"]][,2] should be named 'day'",sep=''))
  if(dims < 2 | dims > 3)
    stop("Dataframes in datalist must have either 2 or 3 columns (1 or 2 for time, +1 for data)")
  for(i in 1:simulations) if(length(datalist[[i]]$day)%%365 != 0)
    stop(paste("Length of datalist[[",i,"]] should be multiple of 365",sep=""))
  if(!(length(xlim)==0 | length(xlim)==2))
    stop("xlim must have length 2")
  if(!(length(ylim)==0 | length(ylim)==2))
    stop("ylim must have length 2")
  if(length(col)!=0 & length(col)!=simulations)
    stop(paste("Number of objects in datalist (",simulations,") and col (",length(col),") must be equal",sep=""))
  if(length(lty)!=0 & length(lty)!=simulations)
    stop(paste("Number of objects in datalist (",simulations,") and lty (",length(lty),") must be equal",sep=""))
  if(!average & !typeof(shade)=="logical"){
    shade=F
    print("shade set to F because average=F")
  }

  time=list() ; variable=list() ; shadesup=list() ; shadeinf=list()
  for(i in 1:simulations) {
    if(average){
      time[[i]] = unique(datalist[[i]][,(dims-1)])
      variable[[i]] = stats::aggregate(datalist[[i]][,dims],by=list(datalist[[i]][,(dims-1)]),FUN=mean,na.rm=T)$x
      if(shade=="sd") {
        sd = stats::aggregate(datalist[[i]][,dims],by=list(datalist[[i]][,(dims-1)]),FUN=stats::sd,na.rm=T)$x
        shadeinf[[i]] = variable[[i]]-sd
        shadesup[[i]] = variable[[i]]+sd
      } else if (shade=="error") {
        shadeinf[[i]]=rep(NA,length(variable[[i]]))
        for(d in 1:365) shadeinf[[i]][d]=stats::quantile(datalist[[i]][which(datalist[[i]][,(dims-1)]==d & !is.na(datalist[[i]][,dims])),dims],probs=0.05,na.rm=F)
        shadesup[[i]]=rep(NA,length(variable[[i]]))
        for(d in 1:365) shadesup[[i]][d]=stats::quantile(datalist[[i]][which(datalist[[i]][,(dims-1)]==d & !is.na(datalist[[i]][,dims])),dims],probs=0.95)
      }
    } else {
      time[[i]] = datalist[[i]][,(dims-1)]
      variable[[i]] = datalist[[i]][,dims]
    }
  }

  if(!average){
    for(i in 1:simulations){ #adds NA's to end every year, which breaks connections in the plot
      nyears=(length(time[[i]]) %/% 365)
      aux=matrix(time[[i]],nrow=365,ncol=nyears)
      aux=rbind(aux,rep(NA,nyears))
      time[[i]]=as.vector(aux)
      aux=matrix(variable[[i]],nrow=365,ncol=nyears)
      aux=rbind(aux,rep(NA,nyears))
      variable[[i]]=as.vector(aux)
    }
  }

  #xlim
  if(length(xlim)==0){
    xlim=c(1,365)
  }
  if(xlim[2]-xlim[1]>180) {
    z=c(1,60,121,182,244,305,365)
    zlabel=c("Jan1","Mar1","May1","Jul1","Sep1","Nov1","Dec31")
  } else {
    z=c(1,32,60,91,121,152,182,213,244,274,305,335,365)
    zlabel=c("Jan1","Feb1","Mar1","Apr1","May1","Jun1","Jul1","Aug1","Sep1","Oct1","Nov1","Dec1","Dec31")
  }
  #z=c(1,91,182,274,365)
  #zlabel=c("Jan1","Apr1","Jul1","Oct1","Dec31")

  #ylim
  if(length(ylim)==0){
    Mymax=c() ; Mymin=c()
    for(i in 1:simulations) Mymax = max(Mymax,max(variable[[i]],na.rm=T))
    for(i in 1:simulations) Mymin = min(Mymin,min(variable[[i]],na.rm=T))
    ylim=limNice(c(Mymin,Mymax))
    #correction: increase limit for legend
    if((ylim[2]-Mymax)/(Mymax-ylim[1])<0.25)
      ylim[2] = roundUpNice((4*Mymax-ylim[1])/3)
  }

  #ylab
  if(length(ylab)==0)
    ylab=names(datalist[[1]])[dims]

  #col
  if(length(col)==0)
    col=1:simulations
  #lty
  if(length(lty)==0)
    lty=rep(1,simulations)

  if(export) {
    if(length(filename)==0) {
      filename=paste(names(datalist[[1]])[dims],"-",paste(label,collapse='-'),".jpeg",sep="")
    } else {
      filename=paste(filename,".jpeg",sep="")
    }
    grDevices::jpeg(filename,width=1200,height=600)
    scale=1.5
    graphics::par(cex=1.8, cex.lab=scale, cex.main=scale, cex.axis=scale, cex.sub=scale, cex.main=scale)
    graphics::par(mar = c(2, 4.5, 2, 2) + 0.2)
  }

  graphics::plot(NA,NA,type='l',
       xlim=xlim,ylim=ylim,
       xlab="",ylab=ylab,
       col=col[i],lty=lty[i],
       xaxt="n" )
  graphics::axis(1,at=z,labels=zlabel,las=1)
  for(i in 1:simulations){
    graphics::lines(time[[i]],variable[[i]],col=col[i],lty=lty[i])
    if(!shade==F){
      RGB=as.numeric(grDevices::col2rgb(col=col[i])/255)
      graphics::polygon(c(time[[i]],rev(time[[i]])),c(shadeinf[[i]],rev(shadesup[[i]])),
                        col=grDevices::rgb(RGB[1],RGB[2],RGB[3],0.25),border=NA)
    }
  }

  if(labels>0){
    graphics::legend("topleft",label,col=col,lty=lty,bty="n",cex=1,ncol=1)
  }

  if(export) {
    grDevices::dev.off()
    print(paste0("figure exported as '",filename,"'"))
  }
}

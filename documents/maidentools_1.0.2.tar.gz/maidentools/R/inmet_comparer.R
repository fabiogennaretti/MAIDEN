#' Comparer of inmet files
#'
#' \code{inmet_comparer} Reads a list of files, analyzes their data, makes
#' tables and plots.
#'
#' @details Analyzes inmet files, plotting and creating a table of temperature
#' and precipitation. Precipitation is smoothed with a 10-day spline
#'
#' @param inmet_list character array, addresses of inmet files
#' @param label character array, labels for each inmet file
#' @param alt_cor logical, whether to correct temperature with altitude
#' (requires inpar files)
#' @param inpar_list character array, addresses of inpar files
#' @param spinup integer, years of spinup, to eliminate from the analysis
#' @param period c(first_year,last_year) or single year, period of the analysis
#' @param months array, months (1 to 12) to consider in the analysis
#' @param splength integer, length (days) of spline to smooth precipitation
#' @param draw logical, whether to plot the meteorology
#'
#' @return Returns a success message upon cropping inmetfile.
#'
#' @note The plotted dataframes are designed to be in the format of the
#' standardized observation files and those created by output_maiden().
#'
#' @examples
#' \dontrun{
#' inmet_list=c("inmet1.txt","inmet2.txt")
#' label=c("example1","example2")
#' #set plot parameters here
#' par(mgp=c(1.5,0.5,0), mar=c(1.5,3,0.5,0.5))
#' x=inmet_comparer(inmet_list,label)
#' }
#'
#' @importFrom utils read.table
#' @importFrom stats aggregate
#' @importFrom stats sd
#' @export

inmet_comparer <- function(inmet_list,label=c(),alt_cor=F,inpar_list=character(),
                           spinup=c(),period=c(),months=1:12,splength=0,draw=T){
  nsites=length(inmet_list)
  for (i in 1:nsites){
    if(!file.exists(inmet_list[i]))
      stop(paste(inmet_list[i],"not found"))
  }
  if(length(label)==0) label=inmet_list
  nlabels=length(label)
  if(nsites != nlabels)
    stop(paste("Number of objects in inmet_list (",nsites,") and labels (",nlabels,") must be equal",sep=""))
  if(alt_cor){
    if(length(inpar_list) != nsites)
      stop(paste("Number of objects in inmet_list (",nsites,") and inpar_list (",length(inpar_list),") must be equal",sep=""))
    for (i in 1:nsites){
      if(!file.exists(inpar_list[i]))
        stop(paste(inpar_list[i],"not found"))
    }
  }
  if(length(spinup)==0) {
    spinup=rep(0,nsites)
  } else if(length(spinup)==1) {
    spinup=rep(spinup,nsites)
  } else {
    stop("variable 'spinup' can only have length 1 or 2")
  }
  if(length(period) == 1)
    period=c(period,period) #single year
  if(length(period) > 2)
    stop("variable 'period' can only have length 1 or 2")
  if(length(which(months<1 | months >12)))
    stop("variable 'months' can only vary from 1 to 12")
  splength=floor(splength)

  prec=rain=snow=Tmin=Tmax=Tavg=list() #daily
  prec_y=rain_y=snow_y=Tmin_y=Tmax_y=Tavg_y=list() #yearly
  prec_m=rain_m=snow_m=Tmin_m=Tmax_m=Tavg_m=list() #monthly
  prec_m_sd=rain_m_sd=snow_m_sd=Tmin_m_sd=Tmax_m_sd=Tavg_m_sd=list() #monthly standard deviation

  last_day=c(31,59,90,120,151,181,212,243,273,304,334,365)
  month=c()
  for (d in 1:365) month=c(month,min(which(last_day>=d)))


  #Main loop to read inmet files
  for (i in 1:nsites){
    inmetfile=inmet_list[i]
    if(file.exists(inmetfile)) {
      inmet=utils::read.table(inmetfile,skip=1)
      if(dim(inmet)[2]==8) names(inmet)=c("year","day","Tmax","Tmin","prec","CO2atm","d13Catm","d18Op")
      if(dim(inmet)[2]==7) names(inmet)=c("year","day","Tmax","Tmin","prec","CO2atm","d13Catm")
      if(dim(inmet)[2]==6) names(inmet)=c("year","day","Tmax","Tmin","prec","CO2atm")
      if(dim(inmet)[2]==5) names(inmet)=c("year","day","Tmax","Tmin","prec")
      inmet=cbind(inmet[,1:2],month=rep(month,dim(inmet)[1]/365),inmet[,3:dim(inmet)[2]])
      #Eliminate spinup and select period
      if(spinup[i]>0) {
        if(dim(inmet)[1]<spinup[i]*365) print(paste(i,"problem"))
        inmet=inmet[-c(1:(spinup[i]*365)),]
      }
      if(length(period)==2){ #id identifies the lines we keep
        id=which(inmet$year>=period[1] & inmet$year<=period[2])
        inmet=inmet[id,]
      } else {
        id=1:(dim(inmet)[1])
      }
      #Correct Prec and Temp
      inmet$prec=inmet$prec*10 #prec from cm to mm
      if(alt_cor){ #correct temperature for altitude
        P=read_inpar(inpar_list[i])
        H_site=P[which(names(P)=="site_elev_cst")]
        H_base=P[which(names(P)=="base_elev_cst")]
        tmax_lr_cst=P[which(names(P)=="tmax_lr_cst")]
        tmin_lr_cst=P[which(names(P)=="tmin_lr_cst")]
        dz=(H_site-H_base)/1000
        inmet$Tmax=inmet$Tmax+dz*tmax_lr_cst
        inmet$Tmin=inmet$Tmin+dz*tmin_lr_cst
      }
    } else {
      id=c()
    }

    #Separate fields
    if (length(id)>0){
      Tmin[[i]]=data.frame(year=inmet$year,day=inmet$day,Tmin=inmet$Tmin)
      Tmax[[i]]=data.frame(year=inmet$year,day=inmet$day,Tmax=inmet$Tmax)
      Tavg[[i]]=data.frame(year=inmet$year,day=inmet$day,Tavg=(inmet$Tmax+inmet$Tmin)/2)
      c=(4-Tavg[[i]]$Tavg)/(6) ; c[c>1]=1 ; c[c<0]=0
      prec[[i]]=data.frame(year=inmet$year,day=inmet$day,prec=inmet$prec)
      rain[[i]]=data.frame(year=inmet$year,day=inmet$day,rain=(1-c)*inmet$prec)
      snow[[i]]=data.frame(year=inmet$year,day=inmet$day,snow=c*inmet$prec)
      if(length(splength)>1){
          prec[[i]]=data.frame(year=prec[[i]]$year,day=prec[[i]]$day,prec=melvinspline(prec[[i]]$prec,ssy=rep(splength,length(prec[[i]]$prec))))
          rain[[i]]=data.frame(year=rain[[i]]$year,day=rain[[i]]$day,rain=melvinspline(rain[[i]]$rain,ssy=rep(splength,length(rain[[i]]$rain))))
          snow[[i]]=data.frame(year=snow[[i]]$year,day=snow[[i]]$day,snow=melvinspline(snow[[i]]$snow,ssy=rep(splength,length(snow[[i]]$snow))))
      }

      filter=list(inmet$month)
      prec_m[[i]] = stats::aggregate(prec[[i]]$prec, by=filter, FUN=mean)
      prec_m_sd[[i]] = stats::aggregate(prec[[i]]$prec, by=filter, FUN=stats::sd)
      names(prec_m[[i]])=c("month","prec")
      rain_m[[i]] = stats::aggregate(rain[[i]]$rain, by=filter, FUN=mean)
      rain_m_sd[[i]] = stats::aggregate(rain[[i]]$rain, by=filter, FUN=stats::sd)
      names(rain_m[[i]])=c("month","rain")
      snow_m[[i]] = stats::aggregate(snow[[i]]$snow, by=filter, FUN=mean)
      snow_m_sd[[i]] = stats::aggregate(snow[[i]]$snow, by=filter, FUN=stats::sd)
      names(snow_m[[i]])=c("month","snow")
      Tmin_m[[i]] = stats::aggregate(Tmin[[i]]$Tmin, by=filter, FUN=mean)
      Tmin_m_sd[[i]] = stats::aggregate(Tmin[[i]]$Tmin, by=filter, FUN=stats::sd)
      names(Tmin_m[[i]])=c("month","Tmin")
      Tmax_m[[i]] = stats::aggregate(Tmax[[i]]$Tmax, by=filter, FUN=mean)
      Tmax_m_sd[[i]] = stats::aggregate(Tmax[[i]]$Tmax, by=filter, FUN=stats::sd)
      names(Tmax_m[[i]])=c("month","Tmax")
      Tavg_m[[i]] = stats::aggregate(Tavg[[i]]$Tavg, by=filter, FUN=mean)
      Tavg_m_sd[[i]] = stats::aggregate(Tavg[[i]]$Tavg, by=filter, FUN=stats::sd)
      names(Tavg_m[[i]])=c("month","Tavg")

      id_m=which(inmet$month %in% months)
      filter=list(inmet$year[id_m])
      prec_y[[i]] = stats::aggregate(prec[[i]]$prec[id_m], by=filter,FUN=sum)
      names(prec_y[[i]])=c("year","prec_y")
      rain_y[[i]] = stats::aggregate(rain[[i]]$rain[id_m], by=filter,FUN=sum)
      names(rain_y[[i]])=c("year","rain_y")
      snow_y[[i]] = stats::aggregate(snow[[i]]$snow[id_m], by=filter,FUN=sum)
      names(snow_y[[i]])=c("year","snow_y")
      Tmin_y[[i]] = stats::aggregate(Tmin[[i]]$Tmin[id_m], by=filter,FUN=mean)
      names(Tmin_y[[i]])=c("year","Tmin_y")
      Tmax_y[[i]] = stats::aggregate(Tmax[[i]]$Tmax[id_m], by=filter,FUN=mean)
      names(Tmax_y[[i]])=c("year","Tmax_y")
      Tavg_y[[i]] = stats::aggregate(Tavg[[i]]$Tavg[id_m], by=filter,FUN=mean)
      names(Tavg_y[[i]])=c("year","Tavg_y")
    } else {
      prec[[i]] = data.frame(year=rep(NA,365),day=1:365,prec=rep(NA,365))
      rain[[i]] = data.frame(year=rep(NA,365),day=1:365,rain=rep(NA,365))
      snow[[i]] = data.frame(year=rep(NA,365),day=1:365,snow=rep(NA,365))
      Tmin[[i]] = data.frame(year=rep(NA,365),day=1:365,Tmin=rep(NA,365))
      Tmax[[i]] = data.frame(year=rep(NA,365),day=1:365,Tmax=rep(NA,365))
      Tavg[[i]] = data.frame(year=rep(NA,365),day=1:365,Tavg=rep(NA,365))
      prec_y[[i]] = data.frame(year=NA,prec_y=NA)
      rain_y[[i]] = data.frame(year=NA,rain_y=NA)
      snow_y[[i]] = data.frame(year=NA,snow_y=NA)
      Tmin_y[[i]] = data.frame(year=NA,Tmin_y=NA)
      Tmax_y[[i]] = data.frame(year=NA,Tmax_y=NA)
      Tavg_y[[i]] = data.frame(year=NA,Tavg_y=NA)
      prec_m[[i]] = data.frame(month=NA,prec=rep(NA,12))
      rain_m[[i]] = data.frame(month=NA,rain=rep(NA,12))
      snow_m[[i]] = data.frame(month=NA,snow=rep(NA,12))
      Tmin_m[[i]] = data.frame(month=NA,Tmin=rep(NA,12))
      Tmax_m[[i]] = data.frame(month=NA,Tmax=rep(NA,12))
      Tavg_m[[i]] = data.frame(month=NA,Tavg=rep(NA,12))
    }
  }

  #Calculate means
  prec_mean=rain_mean=snow_mean=Tmin_mean=Tmax_mean=Tavg_mean=c()
  for (i in 1:nsites){
    prec_mean[i] = round(mean(prec_y[[i]]$prec_y))
    snow_mean[i] = round(mean(snow_y[[i]]$snow_y))
    rain_mean[i] = round(mean(rain_y[[i]]$rain_y))
    Tmin_mean[i] = round(mean(Tmin_y[[i]]$Tmin_y),2)
    Tmax_mean[i] = round(mean(Tmax_y[[i]]$Tmax_y),2)
    Tavg_mean[i] = round(mean(Tavg_y[[i]]$Tavg_y),2)
    label_prec = paste("mean =",prec_mean,"mm/yr")
    label_snow = paste("mean =",snow_mean,"mm/yr")
    label_rain = paste("mean =",rain_mean,"mm/yr")
    label_Tmin = paste("mean =",Tmin_mean,"C")
    label_Tmax = paste("mean =",Tmax_mean,"C")
    label_Tavg = paste("mean =",Tavg_mean,"C")
    if(length(label)>0){
      label_prec = paste(label,label_prec)
      label_snow = paste(label,label_snow)
      label_rain = paste(label,label_rain)
      label_Tmin = paste(label,label_Tmin)
      label_Tmax = paste(label,label_Tmax)
      label_Tavg = paste(label,label_Tavg)
    } else {
      label_prec = paste(1:length(prec_mean),label_prec)
      label_snow = paste(1:length(snow_mean),label_snow)
      label_rain = paste(1:length(rain_mean),label_rain)
      label_Tmin = paste(1:length(Tmin_mean),label_Tmin)
      label_Tmax = paste(1:length(Tmax_mean),label_Tmax)
      label_Tavg = paste(1:length(Tavg_mean),label_Tavg)
    }
  }

  #Plot
  if(draw==T) {
    ylim=c()
    plot_maiden_year(prec,label,ylab="Precipitation (mm/d)",average=T,ylim=ylim)
    plot_maiden_year(snow,label,ylab="Snowfall (mm/d)",average=T,ylim=ylim)
    plot_maiden_year(rain,label,ylab="Rainfall (mm/d)",average=T,ylim=ylim)
    plot_maiden(prec_y,label,ylab="Precipitation (mm/yr)")
    ylim=c()
    plot_maiden_year(Tmin,label,ylab="Min. Temperature (C)",average=T,ylim=ylim)
    plot_maiden_year(Tmax,label,ylab="Max. Temperature (C)",average=T,ylim=ylim)
    plot_maiden_year(Tavg,label,ylab="Mean Temperature (C)",average=T,ylim=ylim)
    plot_maiden(Tavg_y,label,ylab="Mean Temperature (C)")
  }

  if(length(label)==0) label=1:length(Tavg_mean)
  x=data.frame(site=label,prec=prec_mean,snow=snow_mean,rain=rain_mean,Tmin=Tmin_mean,Tmax=Tmax_mean,Tavg=Tavg_mean)
  #write.table(x,file="meteotable.txt",sep=" & ",quote=F,row.names=F)
  return(x)
}

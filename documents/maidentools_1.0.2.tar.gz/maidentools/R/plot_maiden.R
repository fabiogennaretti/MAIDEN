#' Plot Maiden outputs
#'
#' \code{plot_maiden} Plots data frames, from data in mdf2 or mdf3 formats, using
#' the year (for mdf2) or the day (for mdf3) as unit of the x-axis.
#'
#' @details It plots data frames using the fields 'year' and 'day' in the x axis.
#' It is acceptable to have no 'day' field. If export=T, it creates a .jpeg
#' instead of making a plot. If label=character(), no legend is made.
#'
#' @param datalist list(data.frame(time,variable)), list of data frames
#' @param label character vector, labels for each dataframe
#' @param export logical, whether to export the figure instead of plotting
#' @param filename character, name of the exported jpeg
#' @param xlim double vector (length 2), limits of x axis
#' @param ylim double vector (length 2), limits of y axis
#' @param xlab character, label of x axis
#' @param ylab character, label of y axis
#' @param col integer array, line color
#' @param lty integer array, line type
#'
#' @return No return value.
#'
#' @note The plotted data frames are designed in formats mdf2 or mdf3.
#'
#' @examples
#' \dontrun{
#' plot_maiden(list(GPPday),label="Daily simulated GPP",export=TRUE)
#' }
#'
#' @importFrom graphics par
#' @importFrom graphics plot
#' @importFrom graphics lines
#' @importFrom graphics legend
#' @importFrom grDevices jpeg
#' @importFrom grDevices dev.off
#' @importFrom grDevices recordPlot
#' @export

plot_maiden <- function(datalist,label=character(),export=F,filename=character(),
                        xlim=double(),ylim=double(),xlab=character(),ylab=character(),
                        col=c(),lty=c()) {
  if(! typeof(export)=="logical")
    stop("variable 'export' must be logical")
  simulations=length(datalist)
  labels=length(label)
  if(labels>0 & simulations != labels)
    stop(paste("Number of objects in datalist (",simulations,") and labels (",labels,") must be equal",sep=""))
  dims=rep(NA,simulations)
  for(i in 1:simulations) dims[i]=dim(datalist[[i]])[2]
  if(length(unique(dims)) != 1)
    stop("All dataframes in datalist must have the same number of columns")
  dims=unique(dims)
  for(i in 1:simulations) if(dims==2 & names(datalist[[i]])[1] != "year")
    stop(paste("datalist[[",i,"]][,1] (",names(datalist[[i]])[1],") should be named 'year'",sep=""))
  for(i in 1:simulations) if(dims==3 & (names(datalist[[i]])[1] != "year" | names(datalist[[i]])[2] != "day"))
    stop(paste("datalist[[",i,"]][,1] (",names(datalist[[i]])[1],") should be named 'year', datalist[[",i,"]][,2] (",names(datalist[[i]])[2],") should be named 'day'",sep=''))
  if(dims < 2 | dims > 3)
    stop("Dataframes in datalist must have either 2 or 3 columns (1 or 2 for time, +1 for data)")
  if(!(length(xlim)==0 | length(xlim)==2))
    stop("xlim must have length 2")
  if(!(length(ylim)==0 | length(ylim)==2))
    stop("ylim must have length 2")
  if(length(col)!=0 & length(col)!=simulations)
    stop(paste("Number of objects in datalist (",simulations,") and col (",length(col),") must be equal",sep=""))
  if(length(lty)!=0 & length(lty)!=simulations)
    stop(paste("Number of objects in datalist (",simulations,") and lty (",length(lty),") must be equal",sep=""))

  time=list() ; variable=list()
  if(dims==2) for(i in 1:simulations) time[[i]] = datalist[[i]][,1]
  if(dims==3) for(i in 1:simulations) time[[i]] = datalist[[i]][,1] + datalist[[i]][,2]/365
  for(i in 1:simulations) variable[[i]] = datalist[[i]][,dims]

  #xlim
  if(length(xlim)==0){
    Mymax=c() ; Mymin=c()
    for(i in 1:simulations) Mymax = max(Mymax,max(time[[i]]))
    for(i in 1:simulations) Mymin = min(Mymin,min(time[[i]]))
    xlim=c(floor(Mymin),ceiling(Mymax))
  }

  #ylim
  if(length(ylim)==0){
    Mymax=c() ; Mymin=c()
    for(i in 1:simulations) Mymax = max(Mymax,max(variable[[i]],na.rm=T))
    for(i in 1:simulations) Mymin = min(Mymin,min(variable[[i]],na.rm=T))
    ylim=limNice(c(Mymin,Mymax))
    #correction: increase limit for legend
    if((ylim[2]-Mymax)/(Mymax-ylim[1])<0.25)
      ylim[2] = roundUpNice((4*Mymax-ylim[1])/3)
  }

  #xlab and ylab
  if(length(xlab)==0)
    xlab=names(datalist[[1]])[1]
  if(length(ylab)==0)
    ylab=names(datalist[[1]])[dims]

  #col
  if(length(col)==0)
    col=1:simulations
  #lty
  if(length(lty)==0)
    lty=rep(1,simulations)

  if(export) {
    if(length(filename)==0) {
      filename=paste0(names(datalist[[1]])[dims],"-",paste(label,collapse='-'),".jpeg")
    } else {
      filename=paste0(filename,".jpeg")
    }
    grDevices::jpeg(filename,width=1200,height=600)
    scale=1.5
    graphics::par(cex=1.8, cex.lab=scale, cex.main=scale, cex.axis=scale, cex.sub=scale, cex.main=scale)
    graphics::par(mar = c(2, 4.5, 2, 2) + 0.2)
  }

  graphics::plot(NA,NA,type='l',
       xlim=xlim,ylim=ylim,
       xlab=xlab,ylab=ylab,
       col=col[1],lty=lty[1])
  for(i in 1:simulations){
    graphics::lines(time[[i]],variable[[i]],col=col[i],lty=lty[i])
  }

  if(labels>0){
    graphics::legend("topleft",label,col=col,lty=lty,bty="n",cex=1,ncol=1)
  }

  if(export) {
    grDevices::dev.off()
    print(paste0("figure exported as '",filename,"'"))
  }
}

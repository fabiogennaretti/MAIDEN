#' maidentools: Set of R functions for MAIDENiso
#'
#' Standardized functions that allow to interact more easily with MAIDENiso:
#' Create/modify input files, extract outputs, plot datasets.
#'
#' @section Standard data formats:
#' Several functions are designed to function with two data formats created for
#' this package: maiden data frame 2 (mdf2) and maiden data frame 3 (mdf3). These
#' are data frame objects that describe a generic variable (which occupies the
#' last column of the data frame), with the 1 (mdf2) or 2 (mdf3) first columns
#' describing associated time variables. For a variable of name "X":
#' \itemize{
#' \item mdf2 (yearly variable): X = dataframe("year","X")
#' \item mdf3 (daily variable):  X = dataframe("year","day","X")
#' }
#' An output variable "X" from MAIDENiso is automatically extracted in the right
#' format by using the function \code{\link{output_maiden}} with the variable name. The
#'
#' The functions that use variables in the mdf2 or mdf3 format are:
#' \itemize{
#' \item \code{\link{cor_maiden}} Calculates correlations between two variables
#' (both mdf2 or both mdf3) for their common time period
#' \item \code{\link{plot_maiden}} Plot any number of variables (all mdf2 or all
#' mdf3) together, inputing them as a list: list(X1,X2,X3...)
#' \item \code{\link{plot_maiden_year}} Plot any number of variables (all mdf3)
#' together, inputing them as a list: list(X1,X2,X3...)
#' }
#'
#' @section Recommended file structure:
#' A specific tree structure is recommended to work with MAIDENiso, specifically
#' when using custom datasets instead of those those provided with the package.
#' Functions \code{\link{create_dailydata}} and \code{\link{create_inpar}} can
#' use custom data stored under the address specified in the variable 'datadir',
#' as long as the subdirectories and files inside have the appropriate names.
#' From inside the datadir directory, these should be:
#' \itemize{
#' \item ./nc_maps/soil/soilfraction.nc for soil clay/sand fractions in create_inpar
#' \item ./nc_maps/heat_flux/heat_flux.nc for crustal heat flux in create_inpar
#' \item ./CO2/CO2_cycle.txt for CO2 detrended DOY values in create_dailydata
#' \item ./CO2/CO2_yearly.txt for CO2 yearly values in create_dailydata
#' \item ./d13C/d13C_cycle.txt for d13C detrended DOY values in create_dailydata
#' \item ./d13C/d13C_yearly.txt for d13C yearly values in create_dailydata
#' }
#'
#' @section Functions:
#' These are some functions to facilitate the creation of MAIDENiso inputs and
#' run the model.
#' \itemize{
#' \item \code{\link{install_maiden}} Download and compile MAIDENiso
#' \item \code{\link{create_dailydata}} Creates daily CO2/d13C series
#' \item \code{\link{create_inmet}} Create a base input meteorology file
#' \item \code{\link{select_inmet}} Select years from input meteorology
#' \item \code{\link{edit_inmet}} Modifies input meteorology (Delta-Omega)
#' \item \code{\link{create_inpar}} Create a base input parameter file
#' \item \code{\link{read_inpar}} Read parameters from the input parameter file
#' \item \code{\link{edit_inpar}} Edit parameters from the input parameter file
#' \item \code{\link{simulate_maiden}} Run MAIDENiso
#' }
#'
#' These functions are useful to extract outputs and make plots
#' \itemize{
#' \item \code{\link{inmet_comparer}} Compares input meteorology files
#' \item \code{\link{output_maiden}} Extracts outputs in mdf2/mdf3 format
#' \item \code{\link{cor_maiden}} Calculates correlations
#' \item \code{\link{plot_maiden}} Plot in multi-year scale
#' \item \code{\link{plot_maiden_year}} Plot in Jan-Dec scale
#' \item \code{\link{exportplot}} Export current plot
#' }
#'
#' Other functions provide additional utilities. Find the full list of functions
#' in the Index (scroll to the bottom).
#'
#' @section Datasets:
#' The package include some datasets used by the functions \code{\link{create_inpar}}
#' and \code{\link{create_dailydata}}:
#' \itemize{
#' \item \code{\link{CO2_cycle}} Detrended yearly cycle of atmospheric CO2
#' \item \code{\link{CO2_yearly}} Yearly averages of atmospheric CO2
#' \item \code{\link{d13C_cycle}} Detrended yearly cycle of atmospheric d13C
#' \item \code{\link{d13C_yearly}} Yearly averages of atmospheric d13C
#' \item \code{\link{heat_flux_map}} Global map of heat flux from the crust
#' \item \code{\link{clay_map}} Global map of clay composition of soils
#' \item \code{\link{sand_map}} Global map of sand composition of soils
#' }
#'
#' @section Author(s):
#' Ignacio Hermoso de Mendoza (author of v1.0.0)
#'
#' \strong{Maintainers}:
#' \itemize{
#'   \item Ignacio Hermoso de Mendoza \email{ihmn.zgz@@gmail.com}
#'   \item Fabio Gennaretti \email{Fabio.Gennaretti@@uqat.ca}
#' }
#' Beta testers:
#' \itemize{
#'   \item Marceau Badaroux \email{Marceau.Badaroux@@uqat.ca}
#'   \item Lucie Barbier \email{LucieNina.Barbier@@uqat.ca}
#' }
#'
#' @seealso
#' Main MAIDENiso website \url{https://dendro-eco.uqat.ca/maiden/}
#'
#' @docType package
#' @name maidentools
#'
#' @examples
#' \dontrun{
#' #Go to the directory where you wish maiden to be installed
#' maidendir = paste(getwd(),"maiden","maidenexe",sep="/")
#'
#' #Install maiden
#' install_maiden(maidendir)
#'
#' #Create input files for a test run
#' site="testsite"
#' simdir = paste(getwd(),"maiden","simulation",site,sep="/")
#' dir.create(simdir,recursive=TRUE)
#' setwd(paste(getwd(),"maiden",sep="/"))
#' year0=1950 ; year0_sim=1960 ; yearn=2000
#' inmetfile = create_inmet(site,year0,yearn)
#' coord=data.frame(lon=-154.0,lat=67.,alt=1000)
#' time=data.frame(year0=year0,year0_sim=year0_sim,yearn=yearn)
#' isopar=data.frame(a_rain=0.3,b_rain=2,c_rain=-15,
#'                   a_snow=0.3,b_snow=0.,c_snow=16)
#' inparfile = create_inpar(site,coord,time,isopar)
#'
#' #Simulate maiden, extract outputs and plot figures
#' simulate_maiden(simdir=simdir,inmetfile=inmetfile,inparfile=inparfile,maidendir=maidendir,stdout=T)
#' GPPday = output_maiden(simdir, filename="outalloc_d", varname="Acanopy")
#' plot_maiden_year(list(GPPday),label="Daily simulated GPP",export=TRUE,filename="GPPdaily")
#' }
NULL
#> NULL

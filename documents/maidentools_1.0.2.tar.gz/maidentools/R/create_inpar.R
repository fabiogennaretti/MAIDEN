#' Creator of inpar files
#'
#' \code{create_inpar} Creates a basic inpar file in the current directory.
#'
#' @details It creates the inpar file with the parameters that were calibrated
#' in Quebec. It uses the coordinates to change the site parameters and look for
#'  soil composition and heat flux in global map files.
#'
#' @param site string, to name the inpar file
#' @param coord data.frame(lon,lat,alt) with lon in deg E, lat in deg N and alt in m
#' @param time data.frame(year0,year0_sim,yearn)
#' @param isopar data.frame(a_rain,b_rain,c_rain,a_snow,b_snow,c_snow)
#' @param datadir string, where to find the global map files
#'
#' @return Returns address of the created inpar file
#'
#' @note It uses the datasets 'heat_flux_map', 'clay_map and 'sand_map'.
#'
#' @examples
#' \dontrun{
#' site="testsite"
#' coord=data.frame(lon=-154.05,lat=67.43,alt=1063.2)
#' time=data.frame(year0=1950,year0_sim=1970,yearn=2000)
#' isopar=data.frame(a_rain=0.3,b_rain=2,c_rain=-15,
#'                   a_snow=0.3,b_snow=0,c_snow=16)
#' create_inpar(site,coord,time,isopar)
#' }
#'
#' @importFrom utils data
#' @importFrom utils write.table
#' @export

create_inpar <- function(site,coord,time,isopar,datadir=c()) {
  if(length(datadir)==0)
    requireNamespace("ncdf4")
  if(length(isopar)==0)
    isopar=data.frame(a_rain=0.3,b_rain=0,c_rain=0,a_snow=0.3,b_snow=0,c_snow=0)

  Param1=data.frame(V1=matrix(data = NA, nrow = 121, ncol = 2))

  #Generic model parameters
  Param1[1,]=	c(2			,"model_version")
  Param1[2,]=	c(2			,"exp_site")
  Param1[3,]=	c(4			,"nslay")

  #Run parameters: controlled from 'time'
  Param1[17,]=	c(time$year0			,    "year0")
  Param1[18,]=	c(time$yearn			,    "yearn")
  Param1[19,]=	c(time$year0_sim	,    "year0_sim")
  Param1[20,]=	c(time$yearn			,    "yearn_sim")
  Param1[16,]=	c(365*(time$yearn-time$year0+1),    "ndays")

  #Site parameters: controlled from 'coord'
  lon = round(coord$lon,2)
  lat = round(coord$lat,2)
  Param1[6,]=	c(lat			 ,    "site_lat_cst")
  Param1[4,]=	c(coord$alt,    "base_elev_cst")
  Param1[7,]=	c(coord$alt,    "site_elev_cst")
  Param1[5,]=	c(999			 ,    "base_isoh_cst")
  Param1[10,]= c(999		 ,    "site_isoh_cs")
  Param1[21,]=	c(5.		 ,    "ws_cst")

  #isotopic curve parameters: controlled from 'isopar'
  Param1[75,]=	c(isopar$a_rain			,    "a_rain")
  Param1[76,]=	c(isopar$b_rain			,    "b_rain")
  Param1[77,]=	c(isopar$c_rain			,    "c_rain")
  Param1[78,]=	c(isopar$a_snow			,    "a_snow")
  Param1[79,]=	c(isopar$b_snow			,    "b_snow")
  Param1[80,]=	c(isopar$c_snow			,    "c_snow")

  #SOIL PARAMETERS
  if(length(datadir)==0){
    if(lon<0) lon=lon+360 #lon bnds are 0 to 360 deg E

    #utils::data("heat_flux_map")
    heat_flux_map <- (function(...)get(utils::data(...,envir = new.env())))(list="heat_flux_map")
    lon_id = which.min(abs(seq(from=+1,to=+359,by=2)-lon))
    lat_id = which.min(abs(seq(from=-89,to=+89,by=2)-lat))
    heat_flux = round(heat_flux_map[lon_id,lat_id]/1000,4) #mW/m2 to W/m2

    #utils::data("clay_map")
    #utils::data("sand_map")
    clay_map <- (function(...)get(utils::data(...,envir = new.env())))(list="clay_map")
    sand_map <- (function(...)get(utils::data(...,envir = new.env())))(list="sand_map")
    lon_id = which.min(abs(seq(from=+0.125,to=+359.875,by=0.25)-lon))
    lat_id = which.min(abs(seq(from=-59.875,to=+89.875,by=0.25)-lat))
    clay = round(clay_map[lon_id,lat_id],2)*100
    sand = round(sand_map[lon_id,lat_id],2)*100
    if(is.na(clay)) stop(paste0("ocean tile selected in soil map (lon=",lon,", lat=",lat,")"))

  } else {
    heat_flux_nc <- ncdf4::nc_open(paste(datadir,"nc_maps/heat_flux/JC_heat_flux_map.nc",sep="/"))
    if(lon<0) lon=lon+360 #lon bnds are 0 to 360 deg E
    lon_id = which.min(abs(heat_flux_nc$dim$lon$vals-lon))
    lat_id = which.min(abs(heat_flux_nc$dim$lat$vals-lat))
    heat_flux <- ncdf4::ncvar_get(heat_flux_nc,"heat_flux")[lon_id,lat_id]/1000 #mW/m2 to W/m2
    heat_flux = round(heat_flux,4)
    remove(heat_flux_nc)

    soil_nc <- ncdf4::nc_open(paste(datadir,"nc_maps/soil/GLDASp4_soilfraction_025d.nc4",sep="/"))
    if (lon>180) lon=lon-360 #lon bnds are -180 to 180 deg E
    lon_id = which.min(abs(soil_nc$dim$lon$vals-lon))
    lat_id = which.min(abs(soil_nc$dim$lat$vals-lat))
    clay <- ncdf4::ncvar_get(soil_nc,"GLDAS_soilfraction_clay")[lon_id,lat_id]
    sand <- ncdf4::ncvar_get(soil_nc,"GLDAS_soilfraction_sand")[lon_id,lat_id]
    if(is.na(clay)) stop("ocean tile selected from GLDASp4_soilfraction_025d.nc4")
    clay = 100*round(clay,2) #fraction to %
    sand = 100*round(sand,2) #fraction to %
    remove(soil_nc)
  }

  Param1[15,]=	c(heat_flux	,    "site_chf")
  Param1[35,]=	c(0.25			,    "thick1")
  Param1[36,]=	c(0.1			,    "thick2")
  Param1[37,]=	c(0.15			,    "thick3")
  Param1[38,]=	c(0.2			,    "thick4")
  Param1[39,]=	c(0			,    "thick5")
  Param1[40,]=	c(0.6			,    "finefrac1")
  Param1[41,]=	c(0.13			,    "finefrac2")
  Param1[42,]=	c(0.13			,    "finefrac3")
  Param1[43,]=	c(0.13			,    "finefrac4")
  Param1[44,]=	c(0			,    "finefrac5")
  Param1[45,]=	c(clay			,    "clay1	")
  Param1[46,]=	c(clay			,    "clay2	")
  Param1[47,]=	c(clay			,    "clay3	")
  Param1[48,]=	c(clay			,    "clay4	")
  Param1[49,]=	c(0			,    "clay5	")
  Param1[50,]=	c(sand		,    "sand1	")
  Param1[51,]=	c(sand			,    "sand2	")
  Param1[52,]=	c(sand			,    "sand3	")
  Param1[53,]=	c(sand			,    "sand4	")
  Param1[54,]=	c(0			,    "sand5	")

  #CALIBRATED PARAMETERS
  #process: SWE / SNDP
  Param1[82,]=	c(20			,    "rad_trans")
  Param1[83,]=	c(0.			,    "snowblow")
  #process: GPP
  Param1[59,]=	c(41.6302891185185			,    "Vcmax")
  Param1[62,]=	c(-0.197348923492928			,    "b")
  Param1[63,]=	c(16.4718371434673			,    "Ts")
  Param1[56,]=	c(-0.0185244195188596			,    "b_soil")
  Param1[31,]=	c(102.531694326459			,    "soil_stress")
  Param1[66,]=	c(10.2633040711746			,    "s_tday_tau")
  #process: AllocStem
  Param1[114,]=	c(15.8365776393702			,    "LAI_temp")
  Param1[113,]=	c(0.328249013898294			,    "LAI_pr")
  Param1[84,]=	c(14.2813541254848			,    "gdd")
  Param1[87,]=	c(166.793119797323			,    "vegphase23")
  Param1[117,]=	c(9.44741550180765			,    "day23_flex")
  Param1[98,]=	c(1.02238381521773			,    "stor_bud")
  Param1[108,]=	c(0.871880935383978			,    "stor_moist_leaf1")
  Param1[100,]=  c(82.8280722994829			,    "npp_stor")
  Param1[88,]=	c(13.085794058674			,    "photoper")
  Param1[112,]=	c(0.143988995675895		 ,    "perc_lai_fall")
  Param1[115,]=	c(190.989988636806			,    "phenol_sd")
  Param1[116,]=	c(11.9778755465655			,    "phenol_alpha")
  #process: d18O
  Param1[70,]=	c(0.490799697370591			,    "ff_d18O")
  Param1[71,]=	c(29.9995057938113			,    "Eps_bio")
  Param1[81,]=	c(18.6486386347862			,    "Eps_Kin")

  #Other parameters: uncalibrated, seem to be always the same
  Param1[8,]=	c(14.4			,    "site_slp_cst")
  Param1[9,]=	c(73.5			,    "site_asp_cst")
  Param1[11,]=	c(14.4			,    "site_ehoriz_cst")
  Param1[12,]=	c(14.4			,    "site_whoriz_cst")
  Param1[13,]=	c(-6			,    "tmax_lr_cst")
  Param1[14,]=	c(-3			,    "tmin_lr_cst")
  Param1[22,]=	c(1			,    "CO2_flag")
  Param1[23,]=	c(0.17			,    "WAI")
  Param1[24,]=	c(3.3			,    "LAImax")
  Param1[25,]=	c(0.9			,    "k")
  Param1[26,]=	c(10			,    "lai_par")
  Param1[27,]=	c(-9999			,    "abs_compet_k")
  Param1[28,]=	c(0.92			,    "clumping")
  Param1[29,]=	c(0.34			,    "cws_max")
  Param1[30,]=	c(5.9			,    "cws_max_snow")
  Param1[32,]=	c(15			,    "soilwmin")
  Param1[33,]=	c(-9999			,    "sat")
  Param1[34,]=	c(0.2			,    "thaw_thres")
  Param1[55,]=	c(1500			,    "swp_wp")
  Param1[57,]=	c(10.00235			,    "leuning_a")
  Param1[58,]=	c(11493.44			,    "VPD0")
  Param1[60,]=	c(2.7365			,    "JmaxCoef")
  Param1[61,]=	c(0.02562703			,    "RdayCoef")
  Param1[64,]=	c(-0.03920419			,    "perc_vcmax")
  Param1[65,]=	c(0.85			,    "theta_inpar")
  Param1[67,]=	c(-2.5			,    "Photo_Temp_T1")
  Param1[68,]=	c(3.			,    "Photo_Temp_T2")
  Param1[69,]=	c(1			,    "d18O_flag")
  Param1[72,]=	c(-9999			,    "ff_d13C")
  Param1[73,]=	c(0			,    "Dst-dest")
  Param1[74,]=	c(0.7			,    "Dc_p")
  Param1[85,]=	c(3			,    "temp_thres")
  Param1[86,]=	c(41			,    "vegphase12")
  Param1[89,]=	c(9			,    "phenolcount")
  Param1[90,]=	c(2000			,    "C_stem_init")
  Param1[91,]=	c(1500			,    "C_stor_init")
  Param1[92,]=	c(-9999			,    "glumax0")
  Param1[93,]=	c(100			,    "glumin0")
  Param1[94,]=	c(0.004234			,    "SLA")
  Param1[95,]=	c(1.65			,    "root_per_leaf")
  Param1[96,]=	c(0.5			,    "root_turn")
  Param1[97,]=	c(0.47			,    "npp_frac")
  Param1[99,]=	c(-9999			,    "stor_stem")
  Param1[101,]=	c(-9999			,    "stor_day")
  Param1[102,]=	c(250			,    "perc_lai")
  Param1[103,]=	c(0			,    "npp_stor2")
  Param1[104,]=	c(400			,    "b_npp")
  Param1[105,]=	c(2			,    "alpha_npp")
  Param1[106,]=	c(-9999			,    "bud_tmax")
  Param1[107,]=	c(-9999			,    "b_bud_tmax")
  Param1[109,]=	c(-25			,    "bud_leaf_tmax")
  Param1[110,]=	c(70			,    "b_bud_leaf_tmax")
  Param1[111,]=	c(0.49			,    "PercCLeaf")
  Param1[118,]=	c(-9999			,    "CmaxSlope")
  Param1[119,]=	c(60			,    "C_root_growth_min")
  Param1[120,]=	c(255			,    "yday_C_stor_stem")
  Param1[121,]=	c(255			,    "yday_C_stor_stem2")

  if(any(is.na(Param1[,1])))
    stop("NA value in parameter",Param1[which(is.na(Param1[,1])),2] )

  # Write the new file
  inparfile=paste("inpar_",site,".txt",sep="")
  utils::write.table(paste(Param1[,1],Param1[,2],sep="\t\t\t//\t\t"),file=inparfile,row.names=FALSE,col.names=FALSE,quote=FALSE)
  print(paste("Successfully created",inparfile))
  return(paste(getwd(),inparfile,sep="/"))
}

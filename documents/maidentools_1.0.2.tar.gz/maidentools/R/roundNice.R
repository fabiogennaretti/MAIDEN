#' Round Nice
#'
#' \code{roundNice} Upgrade from round(), to round up to nice numbers.
#'
#' @param x numbers to round
#' @param nice numbers considered as nice (without 0s after)
#'
#' @return Returns nicely rounded numbers.
#'
#' @note It mixes roundUpNice and roundDownNice.
#'
#' @keywords internal

roundNice <- function(x, nice=c(1,1.2,1.5,2,3,4,5,6,8,10)) {
  if(length(x) == 0) stop("'x' is empty")

  diff_min = x-roundDownNice(x, nice)
  diff_max = roundUpNice(x, nice)-x
  if(diff_min<diff_max){
    return(roundDownNice(x, nice))
  } else if (diff_min>=diff_max) {
    return(roundUpNice(x, nice))
  } else {
    return (0)
  }
}

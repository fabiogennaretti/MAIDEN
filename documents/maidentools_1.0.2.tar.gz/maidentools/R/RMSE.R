#' Root Mean Square Error
#'
#' \code{RMSE} Calculates RMSE between two vectors.
#'
#' @details vector1 and vector2 must be of same length.
#'
#' @param vector1 vector
#' @param vector2 vector
#'
#' @return Returns the RMSE between vector1 and vector2.
#'
#' @examples
#' vector1=runif(10,min=-1,max=1)
#' vector2=runif(10,min=-1,max=1)
#' RMSE(vector1,vector2)
#'
#' @export

RMSE = function(vector1, vector2){
  nvector1=length(vector1)
  nvector2=length(vector2)
  if(nvector1!=nvector2)
    stop("vector1 and vector2 must have equal length")

  id=c(which(is.na(vector1)),which(is.na(vector2)))
  if(length(id)>0) {
    stop("NA values are not acceptable in RMSE()")
  }
  return(sqrt(mean((vector1 - vector2)^2)))
}

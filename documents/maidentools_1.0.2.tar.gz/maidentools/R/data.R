#' CO2 cycle over the yearly mean
#'
#' 365 values for the yearly cycle of CO2, detrended and 0 mean.
#'
#' @source <https://www.esrl.noaa.gov/gmd/ccgg/trends/data.html>
#' @format Data frame with columns
#' \describe{
#' \item{day}{Day Of Year.}
#' \item{deviation}{Deviation from mean.}
#' }
#' @examples
#'   CO2_cycle
"CO2_cycle"

#' CO2 yearly values
#'
#' Yearly CO2 atmospheric values (0001-2019).
#'
#' @source <https://www.co2.earth/historical-co2-datasets>
#' @format Data frame with columns
#' \describe{
#' \item{year}{Year.}
#' \item{mean}{Mean of year.}
#' }
#' @examples
#'   CO2_yearly
"CO2_yearly"

#' d13C cycle over the yearly mean
#'
#' 365 values for the yearly cycle of d13C, detrended and 0 mean.
#'
#' @source <https://www.esrl.noaa.gov/gmd/ccgg/trends/data.html>
#' @format Data frame with columns
#' \describe{
#' \item{day}{Day Of Year.}
#' \item{deviation}{Deviation from mean.}
#' }
#' @examples
#'   d13C_cycle
"d13C_cycle"

#' d13C yearly values
#'
#' Yearly d13C atmospheric values (1850-2015).
#'
#' @source <Supplement of H. Graven et al. (2017) "Compiled records of carbon
#' isotopes in atmospheric CO2 for historical simulations in CMIP6.">
#' @format Data frame with columns
#' \describe{
#' \item{year}{Year.}
#' \item{mean}{Mean of year.}
#' }
#' @examples
#'   d13C_yearly
"d13C_yearly"

#' Heat flux map
#'
#' Map (resolution 2x2 deg) of continental heat flux (mW / m^-2).
#' Substituted NaN values for oceanic crust and Iceland.
#'
#' @source <Claude Jaupart and Jean-Claude Mareschal. "Heat generation and transport in the Earth.">
#' @format Matrix of 2 dimensions (lon x lat)
#' @examples
#'   heat_flux_map
"heat_flux_map"

#' Clay composition map
#'
#' Map (resolution 0.25x0.25 deg) of clay composition (fraction) of the soil.
#'
#' @source <https://ldas.gsfc.nasa.gov/gldas/soils>
#' @format Matrix of 2 dimensions (lon x lat)
#' @examples
#'   clay_map
"clay_map"

#' Sand composition map
#'
#' Map (resolution 0.25x0.25 deg) of sand composition (fraction) of the soil.
#'
#' @source <https://ldas.gsfc.nasa.gov/gldas/soils>
#' @format Matrix of 2 dimensions (lon x lat)
#' @examples
#'   sand_map
"sand_map"

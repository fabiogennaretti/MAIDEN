#' Reader of inpar files
#'
#' \code{read_inpar} Reads an inpar file and returns it as an array.

#' @details Reads an inpar file and returns it as a dataframe, the row names
#' being the parameter names.

#' @param inparfile string, address of the inpar file
#' @param parnames string array, names of the parameters to extract

#' @return Returns a dataframe with the parameter values.

#' @examples

#' \dontrun{
#' parvalues=read_inpar(inparfile,c("model_version","year0"))
#' }
#'
#' @export

read_inpar<- function(inparfile,parnames=c()){
  if(!file.exists(inparfile))
    stop(paste("Unable to find",inparfile))

  con=file(inparfile,open="r")
  line=readLines(con)
  close(con)
  element=strsplit(line,"//")	#each line is split by "//" into value, name, module and description
  long=length(line)			#total number of parameters
  Paramname=rep(NA,long)			#name of parameters
  Paramvalue=rep(NA,long)			#name of parameters
  for(i in 1:long){
    Paramname[i]=gsub("\t","",element[[i]][2])			#eliminates tab spaces
    Paramname[i]=gsub(" ","",Paramname[i])				#eliminates whitespaces
    Paramvalue[i]=gsub("\t","",element[[i]][1])			#eliminates tab spaces
    Paramvalue[i]=gsub(" ","",Paramvalue[i])    	#eliminates whitespaces
  }
  Paramvalue=array(as.numeric(Paramvalue))
  Paramvalue=data.frame(P=array(as.numeric(Paramvalue)))
  rownames(Paramvalue)=Paramname

  if(length(parnames)>0){
    id=which(rownames(Paramvalue)%in%parnames)
    Paramvalue=Paramvalue[id,]
    Paramvalue=data.frame(P=array(as.numeric(Paramvalue)))
    rownames(Paramvalue)=Paramname[which(Paramname%in%parnames)]
    if(length(id)<length(parnames))
      stop(paste("parameter name",parnames[which(!(parnames %in% rownames(Paramvalue)))],"not found\n"))
  }

  return(Paramvalue)
}

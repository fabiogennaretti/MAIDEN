#' Install MAIDENiso
#'
#' \code{install_maiden} Downloads and installs MAIDENiso from the latest
#' version available.
#'
#' @details It will download the maiden files from \code{baseurl} into the
#' specified folder \code{maidendir}. Then, it will attempt to compile the model
#' and create an executable file.
#'
#' @param maidendir folder where to install MAIDENiso
#' @param baseurl url of the website containing the MAIDENiso files
#'
#' @return Returns 0 if execution was not interrupted.
#'
#' @note Requires the compiler to be installed.
#'
#' @examples
#' \dontrun{
#' install_maiden(maidendir=maidendir,baseurl)
#' }
#'
#' @importFrom utils download.file
#' @export

install_maiden <- function(maidendir,baseurl=c()){
  if(grepl("~",maidendir))
    stop(paste0("Please write the full address for maidendir: unacceptable character '~' in  ",maidendir))
  if(length(baseurl)==0)
    baseurl="https://zenodo.org/record/5597877/files/"
  files=c("allocation_FG_with_GGI_alloc.cpp",
          "Maiden.cpp",
          "meteorology.cpp",
          "MyFunctions.cpp",
          "phenology.cpp",
          "photosynthesis_FG_with_GGI_photo.cpp",
          "photosynthesis_AL.cpp",
          "radiation.cpp",
          "root.cpp",
          "soih2o_iso.cpp",
          "soil_evap.cpp",
          "throughfall_iso.cpp",
          "transpiration.cpp",
          "TRC_isotopes.cpp",
          "Constants.h",
          "Maiden_funct.h",
          "Maiden_struct.h",
          "malloc.h",
          "README.txt",
          "LICENSE.txt",
          "Makefile",
          "runme.bat")
  urls=paste0(baseurl,files,"?download=1")
  if(!dir.exists(maidendir)) {
    dir.create(maidendir,recursive=T)
    print(paste0("created maiden directory ",maidendir))
  } else {
    print(paste0("skipping creation of already existing maiden directory ",maidendir))
  }
  print(paste0("downloading files from ",baseurl))
  for(id in 1:length(urls)){
    if(file.exists(paste(maidendir,files[id],sep="/"))){
      print(paste0("skipping detected file ",files[id]))
    } else {
      download.file(urls[id],destfile=paste(maidendir,files[id],sep="/"))
    }
  }

  #COMPILE
  currentdir=getwd()
  setwd(maidendir)
  print("Attempting compilation of MAIDENiso")
  switch(Sys.info()[['sysname']],
         Windows= {
           system2("./runme.bat", stdout=TRUE)
           executable=list.files(path=maidendir,pattern=".exe")},
         Darwin = {
           system2("make", stdout=TRUE)
           executable=list.files(path=maidendir,pattern=".out")}
  )
  setwd(currentdir)
  if(length(executable)==0)
    return("Executable not found: compilation failed")
  if(length(executable)>1)
    return(paste("Too many executables found:",paste(executable,collapse=", ")))
  if(length(executable)==1)
    return(paste0("Executable ",executable," found: compilation succeeded"))
}

#' Exporter of displayed plots
#'
#' \code{exportplot} It exports the currently displayed plot in jpeg or pdf
#' format.
#'
#' @details It creates a file and replays the current plot there, so width,
#' change and plot parameters can be changed. Default values of width and height
#' are those from pdf() and jpeg() functions.
#'
#' @param title string, name of the plot file
#' @param exportdir directory where to export the plot
#' @param format extension of the plot file
#' @param width width of the plot
#' @param height height of the plot
#'
#' @return No return value.
#'
#' @examples
#' \dontrun{
#' x=(0:100)/100
#' y=sin(x*2*pi)
#' plot(x,y)
#' exportplot(title="Sin",exportdir=getwd(),format="pdf",height=8,width=8)
#' }
#'
#' @importFrom grDevices pdf
#' @importFrom grDevices jpeg
#' @importFrom grDevices recordPlot
#' @importFrom grDevices replayPlot
#' @importFrom grDevices dev.off
#' @export

exportplot <- function(title="plot",exportdir=getwd(),format="pdf",width=c(),height=c()){

  myplot=grDevices::recordPlot()
  outfile=paste(exportdir,"/",title,".",format,sep="")
  if(format=="pdf")
    if(length(width)>0 & length(height)>0) {
      grDevices::pdf(outfile, onefile=TRUE,encoding="MacRoman",width=width,height=height)
    } else {
      grDevices::pdf(outfile, onefile=TRUE,encoding="MacRoman")
    }
  if(format=="jpeg")
    if(length(width)>0 & length(height)>0) {
      grDevices::jpeg(outfile,width=width,height=height)
    } else {
      grDevices::jpeg(outfile)
    }
  grDevices::replayPlot(myplot)
  grDevices::dev.off()
}

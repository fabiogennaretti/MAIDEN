#' Creator of daily data series
#'
#' \code{create_dailydata} Creates a daily series between two years.
#'
#' @details It uses a detrended cycle of 365 values with zero mean. It adds the
#' mean value of the corresponding year, and the calculated trend in yearly mean
#' values.
#'
#' @param year_first integer, first year to create
#' @param year_last integer, last year to create
#' @param data string, data (CO2 or d13C) to create
#' @param datadir string, where to find the data files
#' @param cycle string (address of cycle file) or data frame with the cycle data
#' @param yearly string (address of cycle file) or data frame with the yearly data
#'
#' @return Returns an dataframe with 3 columns (year,day,CO2) of length
#' 365*(1+year_last-year_first).
#'
#' @note Depending on the argument on \code{data}, it uses the cycle and yearly
#' datasets for either CO2 or d13C.
#'
#' @examples
#' \dontrun{
#' create_dailydata(1950,2000,"CO2")
#' }
#'
#' @importFrom utils data
#' @importFrom utils read.table
#' @export

create_dailydata <- function(year_first,year_last,data=c(),datadir=c(),cycle=c(),yearly=c()) {
  if(year_first>year_last)
    stop(paste(year_first,"must be smaller than",year_last))
  options=c("CO2","d13C")
  if(!(data %in% options))
    stop(paste("'data' must be one of:",paste(options,collapse=" / ")))
  if(length(datadir)>0)
    if(!dir.exists(datadir))
      stop(paste("Unable to find",datadir))

  if(length(cycle)>0){
    if(typeof(cycle)=="character"){
      filecycle=cycle
      if(file.exists(filecycle))
        cycle=utils::read.table(filecycle,header=T)
    }
  } else {
    if(length(datadir)>0){
      filecycle=paste(datadir,data,paste0(data,"_cycle",".txt"),sep="/")
      if(file.exists(filecycle))
        cycle=utils::read.table(filecycle,header=T)
    } else {
      varname=paste0(data,"_cycle")
      cycle <- (function(...)get(utils::data(...,envir = new.env())))(list=varname)
    }
  }
  if(length(yearly)>0){
    if(typeof(yearly)=="character"){
      fileyearly=yearly
      if(file.exists(fileyearly))
        yearly=utils::read.table(fileyearly,header=T)
    }
  } else {
    if(length(datadir)>0){
      fileyearly=paste(datadir,data,paste0(data,"_yearly",".txt"),sep="/")
      if(file.exists(fileyearly))
        yearly=utils::read.table(fileyearly,header=T)
    } else {
      varname=paste0(data,"_yearly")
      yearly <- (function(...)get(utils::data(...,envir = new.env())))(list=varname)
    }
  }

  if(dim(cycle)[2]!=2)
    stop(paste0("Object 'cycle' has different dimensions (",dim(cycle)[2],") than 2"))
  if(dim(cycle)[1]<365)
    stop(paste0("length of the ",data," cycle (",dim(cycle)[1],") can't be smaller than 365"))
  if(dim(yearly)[2]!=2)
    stop(paste0("Object 'yearly' has different dimensions (",dim(cycle)[2],") than 2"))
  names(cycle)=c("year","deviation")
  names(yearly)=c("year","mean")
  if(year_first<min(yearly$year))
    stop(paste0("year_first (",year_first,") can't be smaller than ",min(yearly$year)))
  if(year_last>max(yearly$year))
    stop(paste0("year_last (",year_last,") can't be larger than ",max(yearly$year)))

  DD=data.frame(year=rep(year_first:year_last,each=365),
                day=rep(1:365,length(year_first:year_last)),
                DD=rep(NA,365*length(year_first:year_last)))
  for(yr in year_first:year_last){
    k=which(yearly$year==yr)
    if(k==1) {
      slope = (yearly$mean[k+1]-yearly$mean[k])/365 #mean daily increase
    } else if(k==dim(yearly)[1]) {
      slope = (yearly$mean[k]-yearly$mean[k-1])/365 #mean daily increase
    } else {
      slope = (yearly$mean[k+1]-yearly$mean[k-1])/730 #mean daily increase
    }
    trend = slope*(1:365) - mean(slope*(1:365)) #adjusted to mean==0
    DD$DD[which(DD$year==yr)] = yearly$mean[k] + cycle$deviation+ trend
  }
  colnames(DD)[3] = data

  return(DD)
}

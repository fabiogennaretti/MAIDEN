#' Editor of inpar files
#'
#' \code{edit_inpar} Searches for parameters in the inpar file and substitutes
#' their values.
#'
#' @details It looks for the exact parameter names in parname and changes their
#' values with those in parvalue.
#'
#' @param inparfile string, address of the inpar file
#' @param parname character vector c(string1, string2, ...), name of the
#' parameters to edit#'
#' @param parvalue float vector c(value1, value2, ...), new value of the
#' parameters
#'
#' @return Returns a success message upon editing the values in inparfile.
#'
#' @examples
#' \dontrun{
#' inparfile="pathtofile/inpar.txt"
#' #Change the parameters root_per_leaf to 1.2 and d18O_flag to 0
#' edit_inpar(inparfile, c("root_per_leaf","d18O_flag"), c(1.2,0))
#' }
#'
#' @importFrom utils write.table
#' @export

edit_inpar <- function(inparfile, parname, parvalue) {
  if(!file.exists(inparfile))
    stop(paste("Unable to find",inparfile))
  if(length(parname) != length(parvalue))
    stop(paste("Lengths of parname (",length(parname),") and parvalue (",length(parvalue),") must be equal"))

  #Read the inparfile
  con=file(inparfile,open="r")
  line=readLines(con)
  close(con)
  element=strsplit(line,"//")	#each line is split by "//" into value, name, module and description
  long=length(line)			#total number of parameters
  Paramvalue=rep(NA,long)			#value of parameters
  Paramname=rep(NA,long)			#name of parameters
  for(i in 1:long){
    Paramvalue[i]=gsub("\t","",element[[i]][1])			#eliminates tab spaces
    Paramvalue[i]=gsub(" ","",Paramvalue[i])				#eliminates whitespaces
    Paramname[i]=gsub("\t","",element[[i]][2])			#eliminates tab spaces
    Paramname[i]=gsub(" ","",Paramname[i])				#eliminates whitespaces
  }
  Paramvalue=as.numeric(Paramvalue)

  #Modify the inparfile
  for(i in 1:length(parname)){
    id=match(parname[i],Paramname)
    if(is.na(id))
      stop(paste("Unable to find parameter '",parname[i],"'",sep=""))
    Paramvalue[id]=parvalue[i]
  }

  #Overwrite the inparfile
  utils::write.table(paste(Paramvalue,Paramname,sep="\t\t\t//\t\t"), file=inparfile, row.names=FALSE,col.names=FALSE,quote=FALSE)
  return(paste("Successfully edited",inparfile))
}

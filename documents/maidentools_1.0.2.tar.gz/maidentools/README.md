NOTES FOR THE DEVELOPERS

This package does (or aims to) follow the introduction to R packages by Hadley 
Wickham and Jenny Bryan (https://r-pkgs.org/index.html). 

To this purpose, it is suggested to make use of the devtools and roxygen2 packages
(and other packages specified in the introduction). In particular, roxygen2 allows
to manage the documentation in a much easier way making use of roxygen comments in 
the R files. Once these comments have been updated, update the documentation with 
the command:
> devtools::document()

Note that you can also use the following command:
> devtools::check()
which will run devtools::document(), bundle the package, and check everything (same 
as if running <R CMD check>) in the package.


Finally, to build the .tar.gz file (that can be shared around) use the command:
> devtools::build()
